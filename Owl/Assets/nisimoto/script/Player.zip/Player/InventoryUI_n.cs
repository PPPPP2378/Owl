//InventoryUI_n.cs
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using System.Collections.Generic;

public class InventoryUI_n : MonoBehaviour
{
    public GameObject inventoryPanel;
    public TextMeshProUGUI[] itemTexts;

    public GameObject itemInfoPanel;
    public TextMeshProUGUI itemNameText;
    public TextMeshProUGUI itemDescriptionText;
    private bool ignoreNextE = false;
    private List<ItemData_n> displayItems = new List<ItemData_n>();

    private bool isOpen = false;
    private bool isViewingInfo = false;
    private Statue_n currentStatue = null;
    public static InventoryUI_n Instance;
    public bool IsOpen => isOpen;

    void Awake()
    {
        Instance = this;
        Debug.Log("InventoryUI Awake : " + gameObject.scene.name + " / " + gameObject.name);

        Invoke(nameof(CheckState), 0.5f);
    }

    void CheckState()
    {
        Debug.Log(
            "activeSelf=" + gameObject.activeSelf +
            " activeInHierarchy=" + gameObject.activeInHierarchy +
            " enabled=" + enabled
        );
    }
    private int selectID = 0;




    void Start()
    {
        Debug.Log("Start���s");
        inventoryPanel.SetActive(false);
        if (itemInfoPanel != null)
        {
            itemInfoPanel.SetActive(false);
        }
        // ����m�F�p�i��ŏ����j
        /*InventoryManager_n.Instance.AddItem(
            "�Â���",
            "�K�т����Â����B", ItemType.Key,
            null
        );*/
    }
    public void OpenForStatue(Statue_n statue)
    {
        if (statue.currentItem != null)
        {
            statue.currentItem.isPlaced = false;

            statue.currentItem = null;

            statue.SetWeapon(WeaponType_n.None);

            if (statue.puzzle != null)
            {
                statue.puzzle.CheckAnswer();
            }


            currentStatue = null;

            RefreshInventory();

            return;
        }

        // ===== �����u�� =====
        currentStatue = statue;
        isOpen = true;
        inventoryPanel.SetActive(true);
        selectID = 0;

        UpdateInventory();

        ignoreNextE = true;
    }
    void Update()
    {
        Debug.Log("Update���s");
        Debug.Log("Update: isOpen = " + isOpen);
        // TAB�ŊJ��
        if (Input.GetKeyDown(KeyCode.Tab))
        {
            Debug.Log("Tab�����ꂽ");

            if (isViewingInfo)
            {
                Debug.Log("�ڍו\����");
                return;
            }

            isOpen = !isOpen;
            Debug.Log("isOpen = " + isOpen);

            inventoryPanel.SetActive(isOpen);
            Debug.Log("SetActive����");

            if (isOpen)
            {
                selectID = 0;
                UpdateInventory();
                Debug.Log("UpdateInventory����");
            }
        }

        if (!isOpen)
        {
            Debug.Log("isOpen��false�Ȃ̂ŏI��");
            return;
        }

        // �C���x���g�����J���Ă��鎞����E���󂯕t����
        if (Input.GetKeyDown(KeyCode.E))
        {
            if (ignoreNextE)
            {
                ignoreNextE = false;
                return;
            }

            UseSelectedItem();
        }

        if (InventoryManager_n.Instance.itemList.Count == 0)
            return;

        // �ڍו\����
        if (isViewingInfo)
        {
            if (Input.GetKeyDown(KeyCode.Escape) ||
                Input.GetKeyDown(KeyCode.Q))
            {
                itemInfoPanel.SetActive(false);
                isViewingInfo = false;
            }

            return;
        }

        // �J�[�\���ړ�
        if (Input.GetKeyDown(KeyCode.W))
        {
            selectID--;

            if (selectID < 0)
                selectID = InventoryManager_n.Instance.itemList.Count - 1;

            UpdateInventory();
        }

        if (Input.GetKeyDown(KeyCode.S))
        {
            selectID++;

            if (selectID >= InventoryManager_n.Instance.itemList.Count)
                selectID = 0;

            UpdateInventory();
        }

        // Q �ڍ�
        if (Input.GetKeyDown(KeyCode.Q))
        {
            ShowItemInfo();
        }
    }

    void UpdateInventory()
    {
        displayItems.Clear();

        for (int i = 0; i < itemTexts.Length; i++)
        {
            itemTexts[i].gameObject.SetActive(false);
        }

        foreach (ItemData_n item in InventoryManager_n.Instance.itemList)
        {
            if (!item.isPlaced)
            {
                displayItems.Add(item);
            }
        }

        if (selectID >= displayItems.Count)
        {
            selectID = Mathf.Max(0, displayItems.Count - 1);
        }

        for (int i = 0; i < displayItems.Count && i < itemTexts.Length; i++)
        {
            itemTexts[i].gameObject.SetActive(true);

            if (i == selectID)
                itemTexts[i].text = "> " + displayItems[i].itemName;
            else
                itemTexts[i].text = "  " + displayItems[i].itemName;
        }

        foreach (ItemData_n item in InventoryManager_n.Instance.itemList)
        {
            Debug.Log(item.itemName + " / isPlaced = " + item.isPlaced);
        }
    }

    public void RefreshInventory()
    {
        UpdateInventory();
    }

    void ShowItemInfo()
    {
        if (itemInfoPanel == null) return;

        List<ItemData_n> displayItems = new List<ItemData_n>();

        foreach (ItemData_n data in InventoryManager_n.Instance.itemList)
        {
            if (!data.isPlaced)
                displayItems.Add(data);
        }

        if (selectID < 0 || selectID >= displayItems.Count)
            return;

        ItemData_n item = displayItems[selectID];

        itemNameText.text = item.itemName;
        itemDescriptionText.text = item.description;

        itemInfoPanel.SetActive(true);
        isViewingInfo = true;
    }

    void UseSelectedItem()
    {
        Debug.Log("UseSelectedItem �Ăяo��");
        Debug.Log("currentStatue = " + currentStatue);

        if (InventoryManager_n.Instance.itemList.Count == 0)
        {
            Debug.Log("�A�C�e��������܂���");
            return;
        }

        if (selectID < 0 ||
            selectID >= InventoryManager_n.Instance.itemList.Count)
        {
            Debug.Log("selectID���͈͊O");
            return;
        }

        if (selectID < 0 || selectID >= displayItems.Count)
        {
            Debug.Log("selectID���͈͊O");
            return;
        }

        ItemData_n item = displayItems[selectID];

        for (int i = 0; i < InventoryManager_n.Instance.itemList.Count; i++)
        {
            Debug.Log(i + " : "
                + InventoryManager_n.Instance.itemList[i].itemName
                + " / "
                + InventoryManager_n.Instance.itemList[i].weaponType);
        }

        Debug.Log("�I�𒆁F" + item.itemName);
        Debug.Log("����F" + item.weaponType);

        Debug.Log("selectID = " + selectID);
        Debug.Log("item = " + item.itemName);
        Debug.Log("weaponType = " + item.weaponType);

        // ===== ���ɕ������������ =====
        if (currentStatue != null)
        {
            Debug.Log("currentStatue����");

            if (item.itemType != ItemType.Weapon)
            {
                Debug.Log("����ł͂Ȃ�");
                return;
            }

            Debug.Log("SetWeapon���ĂԒ��O");

            if (currentStatue.currentItem != null)
            {
                currentStatue.currentItem.isPlaced = false;
            }

            currentStatue.currentItem = item;
            item.isPlaced = true;
            currentStatue.SetWeapon(item.weaponType);

            if (currentStatue.puzzle != null &&
    currentStatue.puzzle.IsAllPlaced())
            {
                currentStatue.puzzle.CheckAnswer();
            }

            Debug.Log("SetWeapon���Ă񂾒���");

            UpdateInventory();

            currentStatue = null;
            isOpen = false;
            inventoryPanel.SetActive(false);
            return;
        }

        // ===== �ʏ�g�p =====
        switch (item.itemName)
        {
            case "�Â���":
                break;

            case "��":
                break;

            case "�g�p�l�̃����@":
                break;
        }

        Debug.Log("itemList.Count = " + InventoryManager_n.Instance.itemList.Count);

        foreach (ItemData_n data in InventoryManager_n.Instance.itemList)
        {
            Debug.Log(data.itemName + " isPlaced=" + data.isPlaced);
        }
    }
}
