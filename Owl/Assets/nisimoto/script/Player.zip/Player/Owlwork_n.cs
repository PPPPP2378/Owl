//Owlwork_n.cs
using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.Tilemaps;
using System.Collections.Generic;

public class Owlwork_n : MonoBehaviour
{
    //====================
    // �ړ��ݒ�
    //====================

    public float moveSpeed = 5f;
    public float gridSize = 1f;
    public float repeatDelay = 0.2f;

    private float nextMoveTime;
    private bool isMoving;

    // �����Ă������
    private Vector3 facingDirection = Vector3.down;


    //====================
    // UI
    //====================

    // �u���ׂ�v��UI
    public GameObject interactText;

    // �����摜�Ȃǂ�\������p�l��
    public GameObject infoPanel;
    public Image infoImage;

    // ���݂͖��g�p
    public Sprite mysteryImage;


    //====================
    // ���ׂ鏈��
    //====================

    // ���v���C���[�̑O�ɂ���Mystery2
    private Collider2D currentMystery;

    public WallSequenceDoor_n wallSequenceDoor;

    // ���ׂ郌�C���[
    // ���݂�CheckFrontObject�ł͖��g�p
    public LayerMask interactLayer;


    //====================
    // �ǔ���
    //====================

    public LayerMask wallLayer;


    //====================
    // �ÈŃV�X�e��
    //====================

    public bool darkVision = false;

    // �O�����}�X�Ƃ炷��
    public int visionLength = 5;

    public Tilemap darknessTilemap;
    public TileBase darkTile;

    // �O��Ƃ炵���ꏊ
    private readonly List<Vector3Int> lastVisionTiles =
        new List<Vector3Int>();


    //====================
    // �v���C���[�摜
    //====================

    public SpriteRenderer spriteRenderer;

    public Sprite downSprite;
    public Sprite upSprite;
    public Sprite leftSprite;
    public Sprite rightSprite;


    //====================
    // ������
    //====================

    private void Start()
    {
        if (interactText != null)
        {
            interactText.SetActive(false);
        }

        if (infoPanel != null)
        {
            infoPanel.SetActive(false);
        }

        darkVision = true;

        UpdateVision();
    }


    //====================
    // ���t���[������
    //====================

    private void Update()
    {
        if (Keyboard.current == null)
        {
            return;
        }

        // �ŗD��ŏڍ׃p�l���̕�����͂���������
        if (HandleInfoPanel())
        {
            return;
        }

        // ����UI���J���Ă���Ԃ͑�����~�߂�
        if (IsPlayerInputBlocked())
        {
            return;
        }

        // �ړ����͐V�����ړ����󂯕t���Ȃ�
        if (isMoving)
        {
            return;
        }

        // ���͕������擾����
        Vector3 direction = GetInputDirection();

        // �v���C���[�̑O�ɂ���I�u�W�F�N�g���m�F
        CheckFrontObject();

        // E�L�[�Œ��ׂ�
        HandleInteractionInput();

        // �ړ�
        if (direction != Vector3.zero)
        {
            TryMove(direction);
        }
    }


    //====================
    // �ڍ׃p�l��
    //====================

    /// <summary>
    /// �����摜�Ȃǂ̏ڍ׃p�l�������B
    /// �p�l�����J���Ă���ꍇ��true��Ԃ��B
    /// </summary>
    private bool HandleInfoPanel()
    {
        if (infoPanel == null ||
            !infoPanel.activeInHierarchy)
        {
            return false;
        }

        bool closePressed =
            Keyboard.current.spaceKey.wasPressedThisFrame ||
            Keyboard.current.eKey.wasPressedThisFrame ||
            Keyboard.current.escapeKey.wasPressedThisFrame;

        if (closePressed)
        {
            infoPanel.SetActive(false);

            Debug.Log("�ڍ׃p�l������܂���");
        }

        // �p�l���\�����͈ړ��Ȃǂ������Ȃ�
        return true;
    }


    //====================
    // �����~����
    //====================

    private bool IsPlayerInputBlocked()
    {
        // �C���x���g�����J���Ă���
        if (InventoryUI_n.Instance != null &&
            InventoryUI_n.Instance.IsOpen)
        {
            return true;
        }

        // �I�������\������Ă���
        if (MessageManager_n.instance != null &&
            MessageManager_n.instance.isChoiceActive)
        {
            return true;
        }

        // �A�C�e���ڍׂ��J���Ă���
        if (ItemInfoUI_n.Instance != null &&
            ItemInfoUI_n.Instance.IsOpen)
        {
            return true;
        }

        return false;
    }


    //====================
    // �ړ�����
    //====================

    private Vector3 GetInputDirection()
    {
        if (Time.time < nextMoveTime)
        {
            return Vector3.zero;
        }

        Vector3 direction = Vector3.zero;

        if (Keyboard.current.wKey.isPressed)
        {
            direction = Vector3.up;
            SetFacingDirection(direction, upSprite);
        }
        else if (Keyboard.current.sKey.isPressed)
        {
            direction = Vector3.down;
            SetFacingDirection(direction, downSprite);
        }
        else if (Keyboard.current.aKey.isPressed)
        {
            direction = Vector3.left;
            SetFacingDirection(direction, leftSprite);
        }
        else if (Keyboard.current.dKey.isPressed)
        {
            direction = Vector3.right;
            SetFacingDirection(direction, rightSprite);
        }

        if (direction != Vector3.zero)
        {
            nextMoveTime = Time.time + repeatDelay;
        }

        return direction;
    }


    private void SetFacingDirection(
        Vector3 direction,
        Sprite directionSprite)
    {
        facingDirection = direction;

        if (spriteRenderer != null &&
            directionSprite != null)
        {
            spriteRenderer.sprite = directionSprite;
        }

        // �������ς�������_�Ŏ��E���X�V
        UpdateVision();
    }


    //====================
    // �ړ�����
    //====================

    private void TryMove(Vector3 direction)
    {
        Vector3 nextPos =
            transform.position + direction * gridSize;

        Collider2D wallHit = Physics2D.OverlapCircle(
            nextPos,
            0.2f,
            wallLayer
        );

        // �ǂ�����ꍇ�͈ړ����Ȃ�
        if (wallHit != null)
        {
            return;
        }

        StartCoroutine(Move(direction));
    }


    private IEnumerator Move(Vector3 direction)
    {
        isMoving = true;

        Vector3 startPos = transform.position;
        Vector3 endPos =
            startPos + direction * gridSize;

        float elapsedTime = 0f;

        // moveSpeed��0�ȉ��ł��G���[�ɂȂ�Ȃ��悤�ɂ���
        float safeSpeed = Mathf.Max(moveSpeed, 0.01f);
        float moveTime = 1f / safeSpeed;

        while (elapsedTime < moveTime)
        {
            float rate = elapsedTime / moveTime;

            transform.position = Vector3.Lerp(
                startPos,
                endPos,
                rate
            );

            elapsedTime += Time.deltaTime;

            yield return null;
        }

        transform.position = endPos;

        isMoving = false;

        // �ړ�������ɑO���Ǝ��E���X�V
        CheckFrontObject();
        UpdateVision();
    }


    //====================
    // E�L�[����
    //====================

    private void HandleInteractionInput()
    {
        if (!Keyboard.current.eKey.wasPressedThisFrame)
        {
            return;
        }

        // �I�����\�����͒��ׂ��Ȃ�
        if (MessageManager_n.instance != null &&
            MessageManager_n.instance.isChoiceActive)
        {
            return;
        }

        // �ʏ탁�b�Z�[�W�\�����͐V�������ׂȂ�
        if (MessageManager_n.instance != null &&
            MessageManager_n.instance.messageText != null &&
            MessageManager_n.instance.messageText.gameObject.activeSelf)
        {
            return;
        }

        CheckInteraction();
    }


    //====================
    // ���ׂ�Ώۂ̏���
    //====================

    private void CheckInteraction()
    {
        if (currentMystery == null)
        {
            Debug.Log("���ׂ�Ώۂ�����܂���");
            return;
        }

        Debug.Log("���ׂ�ΏہF" + currentMystery.name);


        //====================
        // ��̕�
        //====================

        MysteryWall_n wall =
            currentMystery.GetComponent<MysteryWall_n>();

        if (wall != null)
        {
            wall.isChecked = true;

            if (wallSequenceDoor != null)
            {
                wallSequenceDoor.CheckWall(
                    wall.wallNumber
                );
            }

            currentMystery = null;

            SetInteractTextVisible(false);
            CheckFrontObject();

            return;
        }


        //====================
        // �A�C�e��
        //====================

        Item_n item =
            currentMystery.GetComponent<Item_n>();

        if (item != null)
        {
            item.GetItem();

            currentMystery = null;

            SetInteractTextVisible(false);

            return;
        }


        //====================
        // �Α�
        //====================

        Statue_n statue =
            currentMystery.GetComponent<Statue_n>();

        if (statue != null)
        {
            Debug.Log("�Α��𒲂ׂ܂���");

            if (InventoryUI_n.Instance != null)
            {
                InventoryUI_n.Instance.OpenForStatue(
                    statue
                );
            }

            return;
        }


        //====================
        // �G��
        //====================

        Painting_n painting =
            currentMystery.GetComponent<Painting_n>();

        if (painting != null)
        {
            Debug.Log("�G��̏ڍׂ�\�����܂�");

            painting.ShowInfo();

            return;
        }


        //====================
        // �G��̔�
        //====================

        PaintingDoor_n door =
            currentMystery.GetComponent<PaintingDoor_n>();

        if (door != null)
        {
            door.ShowQuestion();

            return;
        }


        //====================
        // ����
        //====================

        Memo_n memo =
            currentMystery.GetComponent<Memo_n>();

        if (memo != null)
        {
            ShowMemo(memo);

            return;
        }

        Debug.LogWarning(
            currentMystery.name +
            "�ɂ͑Ή����钲�ׂ鏈��������܂���"
        );
    }


    //====================
    // �����\��
    //====================

    private void ShowMemo(Memo_n memo)
    {
        if (memo.memoImage != null)
        {
            if (infoImage == null ||
                infoPanel == null)
            {
                Debug.LogWarning(
                    "infoImage�܂���infoPanel���ݒ肳��Ă��܂���"
                );

                return;
            }

            infoImage.sprite = memo.memoImage;
            infoPanel.SetActive(true);

            Debug.Log("�����摜��\�����܂���");

            return;
        }

        if (MessageManager_n.instance != null)
        {
            MessageManager_n.instance.ShowMessage(
                memo.memoText
            );
        }
    }


    //====================
    // �O���̃I�u�W�F�N�g�m�F
    //====================

    private void CheckFrontObject()
    {
        Vector2 checkPos =
            (Vector2)transform.position +
            (Vector2)facingDirection * gridSize;

        Collider2D[] hits =
            Physics2D.OverlapCircleAll(
                checkPos,
                0.7f
            );

        currentMystery = null;

        foreach (Collider2D hit in hits)
        {
            if (!hit.CompareTag("Mystery2"))
            {
                continue;
            }

            // �����ς݂̓�̕ǂ͏��O
            MysteryWall_n wall =
                hit.GetComponent<MysteryWall_n>();

            if (wall != null && wall.isChecked)
            {
                continue;
            }

            currentMystery = hit;
            break;
        }

        SetInteractTextVisible(
            currentMystery != null
        );
    }


    private void SetInteractTextVisible(bool visible)
    {
        if (interactText != null)
        {
            interactText.SetActive(visible);
        }
    }


    //====================
    // �Èł̎��E����
    //====================

    private void UpdateVision()
    {
        if (!darkVision ||
            darknessTilemap == null)
        {
            return;
        }

        // �O��Ƃ炵���ꏊ���Èłɖ߂�
        foreach (Vector3Int pos in lastVisionTiles)
        {
            darknessTilemap.SetTile(
                pos,
                darkTile
            );
        }

        lastVisionTiles.Clear();

        Vector3 currentPos = transform.position;

        for (int i = 1; i <= visionLength; i++)
        {
            Vector3 worldPos =
                currentPos +
                facingDirection * i * gridSize;

            Collider2D wall = Physics2D.OverlapCircle(
                worldPos,
                0.2f,
                wallLayer
            );

            // �ǂ���͏Ƃ炳�Ȃ�
            if (wall != null)
            {
                break;
            }

            Vector3Int cell =
                darknessTilemap.WorldToCell(
                    worldPos
                );

            // �����^�C��������
            darknessTilemap.SetTile(
                cell,
                null
            );

            // ��Ō��ɖ߂����߂ɕۑ�
            lastVisionTiles.Add(cell);
        }
    }
}