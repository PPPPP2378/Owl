//MessageManager_n.cs
using UnityEngine;
using TMPro;
using System.Collections;

public class MessageManager_n : MonoBehaviour
{
    public static MessageManager_n instance;

    public TextMeshProUGUI messageText;

    public GameObject choicePanel;
    public TextMeshProUGUI choiceText1;
    public TextMeshProUGUI choiceText2;

    public Painting_n currentPainting;

    int selectChoice = 0;

    string currentChoice1;
    string currentChoice2;

    public bool isChoiceActive = false;
    public bool isDoorChoice = false;

    bool canSelect = false;

    IEnumerator DelayChoiceInput()
    {
        canSelect = false;

        yield return null;

        canSelect = true;
    }

    void Awake()
    {
        instance = this;
    }

    public void ShowMessage(string message)
    {
        Debug.Log("ShowMessage�J�n");

        if (messageText == null)
        {
            Debug.LogError("messageText �� null");
            return;
        }

        // �������ǉ�
        messageText.gameObject.SetActive(true);

        messageText.text = message;

        Debug.Log("�\�������F" + message);
    }

    public void ShowChoice(string choice1, string choice2)
    {
        currentChoice1 = choice1;
        currentChoice2 = choice2;

        selectChoice = 0;  // �K�����ׂ鑤

        choicePanel.SetActive(true);

        isChoiceActive = true;


        UpdateChoice();

        StartCoroutine(DelayChoiceInput());

        Debug.Log("�I�����J�n selectChoice=" + selectChoice);
    }

    void Update()
    {
        if (PaintingSelect_n.Instance != null &&
     PaintingSelect_n.Instance.panel.activeSelf)
        {
            return;
        }


        if (Input.GetKeyDown(KeyCode.Space))
        {
            HideMessage();
            HideChoice();
        }

        if (Input.GetKeyDown(KeyCode.W))
        {
            selectChoice = 0;
            UpdateChoice();
        }

        if (Input.GetKeyDown(KeyCode.S))
        {
            selectChoice = 1;
            UpdateChoice();
        }

        if (Input.GetKeyDown(KeyCode.E) &&
     choicePanel.activeSelf &&
     canSelect)
        {
            SelectChoice();
        }
    }

    public void HideMessage()
    {
        Debug.Log("HideMessage���s");

        messageText.text = "";
        messageText.gameObject.SetActive(false);

        choicePanel.SetActive(false);
    }

    public void HideChoice()
    {
        choicePanel.SetActive(false);
        isChoiceActive = false;
    }


    void UpdateChoice()
    {
        if (selectChoice == 0)
        {
            choiceText1.text = "> " + currentChoice1;
            choiceText2.text = "  " + currentChoice2;
        }
        else
        {
            choiceText1.text = "  " + currentChoice1;
            choiceText2.text = "> " + currentChoice2;
        }
    }

    void SelectChoice()
    {
        Debug.Log("���菈���J�n");
        Debug.Log("selectChoice = " + selectChoice);

        if (selectChoice == 0)
        {
            Debug.Log("���ׂ邪�I�΂ꂽ");

            HideChoice();

            // ===== �G�� =====
            if (currentPainting != null)
            {
                currentPainting.CheckPainting();
                return;
            }

            // ===== �G��̔� =====
            if (isDoorChoice)
            {
                PaintingSelect_n.Instance.Open();
                return;
            }
        }
        else
        {
            Debug.Log("��߂邪�I�΂ꂽ");

            HideChoice();
            HideMessage();
        }
    }
}
