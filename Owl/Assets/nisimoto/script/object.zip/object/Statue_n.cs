//Statue_n.cs
using UnityEngine;

public class Statue_n : MonoBehaviour
{
    public int statueID;
    public Transform weaponPoint;

    public GameObject swordPrefab;
    public GameObject axePrefab;
    public GameObject shieldPrefab;
    public GameObject spearPrefab;
    public GameObject bowPrefab;

    public ItemData_n currentItem;

    private GameObject currentWeaponObject;

    public WeaponType_n currentWeapon = WeaponType_n.None;

    public StatuePuzzle_n puzzle;

    public void SetWeapon(WeaponType_n weapon)
    {
        if (weapon == WeaponType_n.None)
        {
            currentWeapon = WeaponType_n.None;

            if (currentWeaponObject != null)
            {
                Destroy(currentWeaponObject);
                currentWeaponObject = null;
            }

            return;
        }

        Debug.Log("SetWeapon ���� = " + weapon);

        currentWeapon = weapon;
        Debug.Log("currentWeapon = " + currentWeapon);

        // �O�̕��������
        if (currentWeaponObject != null)
        {
            Destroy(currentWeaponObject);
        }

        GameObject prefab = null;

        Debug.Log("switch�ɓ��� weapon = " + weapon);

        switch (weapon)
        {
            case WeaponType_n.Sword:
                prefab = swordPrefab;
                break;

            case WeaponType_n.Axe:
                prefab = axePrefab;
                break;

            case WeaponType_n.Shield:
                prefab = shieldPrefab;
                break;

            case WeaponType_n.Spear:
                prefab = spearPrefab;
                break;

            case WeaponType_n.Bow:
                prefab = bowPrefab;
                break;
        }

        Debug.Log("��������Prefab = " + (prefab != null ? prefab.name : "NULL"));


        // ����𐶐�
        if (prefab != null)
        {
            currentWeaponObject = Instantiate(
     prefab,
     weaponPoint.position,
     weaponPoint.rotation,
      weaponPoint
 );
            currentWeaponObject.GetComponent<SpriteRenderer>().color = Color.red;
            currentWeaponObject.GetComponent<SpriteRenderer>().sortingOrder = 100;
            currentWeaponObject.transform.position = new Vector3(0, 0, 0);

            currentWeaponObject.transform.localScale = new Vector3(0.3f, 0.3f, 1);

            Debug.Log("�������ꂽ�I�u�W�F�N�g = " + currentWeaponObject.name);
            currentWeaponObject.transform.localPosition = Vector3.zero;
            currentWeaponObject.transform.localRotation = Quaternion.identity;
        }

        

     

        Debug.Log("��" + statueID + " �� " + weapon + " ����������");

        Debug.Log(gameObject.name + " �� " + weapon + " ���Z�b�g");
    }
}
